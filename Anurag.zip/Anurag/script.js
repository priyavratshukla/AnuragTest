
resultDiv.style.display = 'none';
function dispense(){

var amount =  document.getElementById('amount').value;
var note1 = document.getElementById('note1');
var note2 = document.getElementById('note2');
var note5 = document.getElementById('note5');
var note10 = document.getElementById('note10');
var note20 = document.getElementById('note20');
var note50 = document.getElementById('note50');
var note100 = document.getElementById('note100');
var note200 = document.getElementById('note200');
var note500 = document.getElementById('note500');
var note2000 = document.getElementById('note2000');
var totalNotes = 0;
note1.innerHTML = 0;
note2.innerHTML = 0;
note5.innerHTML = 0;
note10.innerHTML = 0;
note20.innerHTML = 0;
note50.innerHTML = 0;
note100.innerHTML = 0;
note200.innerHTML = 0;
note500.innerHTML = 0;
note2000.innerHTML = 0;

if(amount && amount > 0){
var resultDiv = document.getElementById('resultDiv');
var remainderAmount = amount % 2000;
var noOf2000Notes = amount / 2000;
if(noOf2000Notes >= 1){
	note2000.innerHTML = Math.floor(noOf2000Notes);
	totalNotes +=  Math.floor(noOf2000Notes);
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 500;
	var noOf500Notes = amount / 500;
	if(noOf500Notes >= 1){
		note500.innerHTML = Math.floor(noOf500Notes);
		totalNotes +=  Math.floor(noOf500Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 200;
	var noOf200Notes = amount / 200;
	console.log(noOf200Notes);
	if(noOf200Notes >= 1){
		note200.innerHTML = Math.floor(noOf200Notes);
		totalNotes +=  Math.floor(noOf200Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 100;
	var noOf100Notes = amount / 100;
	if(noOf100Notes >= 1){
		note100.innerHTML = Math.floor(noOf100Notes);
		totalNotes +=  Math.floor(noOf100Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 50;
	var noOf50Notes = amount / 50;
	if(noOf50Notes >= 1){
		note50.innerHTML = Math.floor(noOf50Notes);
		totalNotes +=  Math.floor(noOf50Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 20;
	var noOf20Notes = amount / 20;
	if(noOf20Notes >= 1){
		note20.innerHTML = Math.floor(noOf20Notes);
		totalNotes +=  Math.floor(noOf20Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 10;
	var noOf10Notes = amount / 10;
	if(noOf10Notes >= 1){
		note10.innerHTML = Math.floor(noOf10Notes);
		totalNotes +=  Math.floor(noOf10Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 5;
	var noOf5Notes = amount / 5;
	if(noOf5Notes >= 1){
		note5.innerHTML = Math.floor(noOf5Notes);
		totalNotes +=  Math.floor(noOf5Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 2;
	var noOf2Notes = amount / 2;
	if(noOf2Notes >= 1){
		note2.innerHTML = Math.floor(noOf2Notes);
		totalNotes +=  Math.floor(noOf2Notes);
	}
}
if(remainderAmount > 0){
	console.log(remainderAmount);
	amount = remainderAmount;
	remainderAmount = amount % 1;
	var noOf1Notes = amount / 1;
	if(noOf1Notes >= 1){
		note1.innerHTML = Math.floor(noOf1Notes);
		totalNotes +=  Math.floor(noOf1Notes);
	}
}
document.getElementById('totalNotes').innerHTML = totalNotes;
resultDiv.style.display = 'inline-block';
}
else if(amount < 1){
alert('Please enter more value than 0.');
}
else if(amount == undefined || amount == null || amount == ''){
alert('Please put valid value.');
}
else{
alert('Something went wrong!');
}
}